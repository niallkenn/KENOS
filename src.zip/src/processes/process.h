#ifndef PROCESSH
#define PROCESSH

// max number of processes that can exist at once
#define MAX_PROCESSES 16
// size of user and kernel stacks for processes
#define STACK_SIZE 4096

#include "definitions.h"

// different process states
typedef enum {
    PROCESS_UNUSED,
    PROCESS_READY,
    PROCESS_RUNNING,
    PROCESS_TERMINATED
} process_state_t;

/* registers context for switching and pasing
process, to transfer between different states */
typedef struct cpu_context_t {
    uint32_t eax;
    uint32_t ebx;
    uint32_t ecx;
    uint32_t edx;
    uint32_t esi;
    uint32_t edi;
    uint32_t ebp;
    uint32_t esp;
    uint32_t eip;
    uint32_t eflags;
} cpu_context_t;

// process data
typedef struct process_t {
    uint32_t pid;
    process_state_t state;

    uint32_t esp;
    uint8_t* kernel_stack;
    uint8_t* user_stack;

    int priority;
    int ticks_in_slice;
    int total_ticks;
} process_t;

extern process_t processes[MAX_PROCESSES];
extern uint8_t kernel_stacks[MAX_PROCESSES][STACK_SIZE];
extern uint8_t user_stacks[MAX_PROCESSES][STACK_SIZE];
extern int next_pid;
extern process_t idle_process;
extern uint8_t idle_stack[STACK_SIZE];

// process functions
process_t* process_create(void (*entry_point)(void));
extern void processes_init();
extern void idle_create(void);
extern process_t* current_process;
extern void idle(void);
#endif