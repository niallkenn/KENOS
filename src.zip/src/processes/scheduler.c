#include "scheduler.h"

const int time_slice[NUM_QUEUES] = {2, 4, 8};
static int ticks_since_boost = 0;

process_t* scheduler_get_next() {
    if (++ticks_since_boost >= BOOST_INTERVAL) {
        ticks_since_boost = 0;
        for (int i = 0; i < MAX_PROCESSES; i++) {
            if (processes[i].state == PROCESS_READY || processes[i].state == PROCESS_RUNNING) {
                processes[i].priority = 0;
                processes[i].ticks_in_slice = 0;
            }
        }
    }

    for (int q = 0; q < NUM_QUEUES; q++) {
        for (int i = 0; i < MAX_PROCESSES; i++) {
            if (processes[i].state == PROCESS_READY && processes[i].priority == q) {
                return &processes[i];
            }
        }
    }

    return &idle_process;
}