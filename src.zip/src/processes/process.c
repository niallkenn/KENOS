#include "process.h"

// initialise
process_t processes[MAX_PROCESSES];
uint8_t kernel_stacks[MAX_PROCESSES][STACK_SIZE];
uint8_t user_stacks[MAX_PROCESSES][STACK_SIZE];
int next_pid = 1;

process_t idle_process;
uint8_t idle_stack[STACK_SIZE];

process_t* current_process = NULL;

process_t* process_create(void (*entry_point)(void)) {
    int slot = -1;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].state == PROCESS_UNUSED || processes[i].state == PROCESS_TERMINATED) {
            slot = i;
            break;
        }
    }
    if (slot == -1) return NULL;

    process_t* process = &processes[slot];
    process->pid = next_pid++;
    process->state = PROCESS_READY;
    process->priority = 0;
    process->ticks_in_slice = 0;
    process->total_ticks = 0;

    uint8_t* kernel_stack = &kernel_stacks[slot][STACK_SIZE];
    uint8_t* user_stack = &user_stacks[slot][STACK_SIZE];

    process->kernel_stack = kernel_stack;

    // fake interrupt frame to iret into entry point
    uint32_t* sp = (uint32_t*)kernel_stack;

    // ss, esp, eflags, cs, eip
    *(--sp) = 0x23;
    *(--sp) = (uint32_t)user_stack;
    *(--sp) = 0x202;
    *(--sp) = 0x1B;
    *(--sp) = (uint32_t)entry_point;

    // interrupt vector and error code
    for (int i = 0; i < 2; i++) *(--sp) = 0;

    // eax, ecx, edx, ebx, esp, ebp, esi, edi
    for (int i = 0; i < 8; i++) *(--sp) = 0;

    // ds, es, fs, gs
    for (int i = 0; i < 4; i++) *(--sp) = 0x23;

    process->esp = (uint32_t)sp;

    return process;
}

void idle_create(void) {
    idle_process.pid = 0;
    idle_process.state = PROCESS_READY;
    idle_process.kernel_stack = &idle_stack[STACK_SIZE];
    idle_process.user_stack = NULL;

    uint32_t* sp = (uint32_t*)idle_process.kernel_stack;

    *(--sp) = 0x10;
    *(--sp) = (uint32_t)idle_process.user_stack;
    *(--sp) = 0x202;
    *(--sp) = 0x08;
    *(--sp) = (uint32_t)idle;

    for (int i = 0; i < 2; i++) *(--sp) = 0;   // vector + error code
    for (int i = 0; i < 8; i++) *(--sp) = 0;   // pusha
    for (int i = 0; i < 4; i++) *(--sp) = 0x10; // ds, es, fs, gs = kernel data

    idle_process.esp = (uint32_t)sp;
}

void idle(void) {
    while(1) asm volatile("sti; hlt");
}

void processes_init() {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        processes[i].state = PROCESS_UNUSED;
    }
}
